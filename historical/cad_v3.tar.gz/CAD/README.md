The gcode file is suitable for laser cutting. The enclosure 'top' is cut (so not from the inside, but from the outside).

The combined gcode file now includes the pcb and lettering. 

Since the lettering is only 'cut' once, it's maintained separately. It currently takes about 30 minutes to cut, which should come down to about 20 minutes with fine tuning.
